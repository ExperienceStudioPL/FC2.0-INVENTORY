return {
	Weapons = {

		['WEAPON_ADVANCEDRIFLE'] = {
			label = 'Advanced Rifle',
			weight = 1500,
			ammoname = 'ammo-rifle',
		},

		['WEAPON_APPISTOL'] = {
			weight = 1200,
			ammoname = 'ammo-pistol',
		},

		['WEAPON_ASSAULTRIFLE'] = {
			label = 'Assault Rifle',
			weight = 1450,
			ammoname = 'ammo-rifle2',
		},

		['WEAPON_ASSAULTRIFLE_MK2'] = {
			label = 'Assault Rifle MK2',
			weight = 1500,
			ammoname = 'ammo-rifle2',
		},

		['WEAPON_ASSAULTSHOTGUN'] = {
			label = 'Assault Shotgun',
			weight = 1500,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_ASSAULTSMG'] = {
			label = 'Assault SMG',
			weight = 1500,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BALL'] = {
			label = 'Ball',
			weight = 150,
			throwable = true,
		},

		['WEAPON_BAT'] = {
			label = 'Bat',
			weight = 800,
		},

		['WEAPON_BATTLEAXE'] = {
			label = 'Battle Axe',
			weight = 900,
		},

		['WEAPON_BOTTLE'] = {
			label = 'Bottle',
			weight = 400,
		},

		['WEAPON_BULLPUPRIFLE'] = {
			label = 'Bullpup Rifle',
			weight = 1200,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BULLPUPRIFLE_MK2'] = {
			label = 'Bullpup Rifle MK2',
			weight = 1200,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_BULLPUPSHOTGUN'] = {
			label = 'Bullpup Shotgun',
			weight = 1250,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_BZGAS'] = {
			label = 'BZ Gas',
			weight = 500,
			throwable = true,
		},

		['WEAPON_CARBINERIFLE'] = {
			label = 'Carbine Rifle',
			weight = 1600,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_CARBINERIFLE_MK2'] = {
			label = 'Carbine Rifle MK2',
			weight = 1700,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_CERAMICPISTOL'] = {
			label = 'Ceramic Pistol',
			weight = 1200,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_COMBATMG'] = {
			label = 'Combat MG',
			weight = 1300,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_COMBATMG_MK2'] = {
			label = 'Combat MG MK2',
			weight = 1300,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_COMBATPDW'] = {
			label = 'Combat PDW',
			weight = 1300,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_COMBATPISTOL'] = {
			label = 'Combat Pistol',
			weight = 1000,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_COMBATSHOTGUN'] = {
			label = 'Combat Shotgun',
			weight = 1300,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_COMPACTRIFLE'] = {
			label = 'Compact Rifle',
			weight = 1300,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_CROWBAR'] = {
			label = 'Crowbar',
			weight = 1000,
		},

		['WEAPON_DAGGER'] = {
			label = 'Dagger',
			weight = 800,
		},

		['WEAPON_DBSHOTGUN'] = {
			label = 'Double Barrel Shotgun',
			weight = 1400,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_DOUBLEACTION'] = {
			label = 'Double Action Revolver',
			weight = 1500,
			ammoname = 'ammo-38'
		},

		['WEAPON_FIREEXTINGUISHER'] = {
			label = 'Gaśnica',
			weight = 1500,
		},

		['WEAPON_FIREWORK'] = {
			label = 'Firework Launcher',
			weight = 2000,
		},

		['WEAPON_FLARE'] = {
			label = 'Flare',
			weight = 400,
			throwable = true,
		},

		['WEAPON_FLAREGUN'] = {
			label = 'Flare Gun',
			weight = 1000,
			ammoname = 'ammo-flare'
		},

		['WEAPON_FLASHLIGHT'] = {
			label = 'Latarka',
			weight = 800,
		},

		['WEAPON_GOLFCLUB'] = {
			label = 'Kij Golfowy',
			weight = 900,
		},

		['WEAPON_GRENADE'] = {
			label = 'Granat',
			weight = 700,
			throwable = true,
		},

		['WEAPON_GUSENBERG'] = {
			label = 'Gusenberg',
			weight = 1500,
			ammoname = 'smg_ammo'
		},

		['WEAPON_HAMMER'] = {
			label = 'Młot',
			weight = 1450,
		},

		['WEAPON_HATCHET'] = {
			label = 'Siekiera',
			weight = 1500,
		},

		['WEAPON_HAZARDCAN'] = {
			label = 'Hazard Can',
			weight = 700,
		},

		['WEAPON_HEAVYPISTOL'] = {
			label = 'Heavy Pistol',
			weight = 1200,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_HEAVYSHOTGUN'] = {
			label = 'Heavy Shotgun',
			weight = 1300,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_HEAVYSNIPER'] = {
			label = 'Heavy Sniper',
			weight = 1500,
			ammoname = 'ammo-heavysniper'
		},

		['WEAPON_HEAVYSNIPER_MK2'] = {
			label = 'Heavy Sniper MK2',
			weight = 1600,
			ammoname = 'ammo-heavysniper'
		},

		['WEAPON_KNIFE'] = {
			label = 'Knife',
			weight = 400,
		},

		['WEAPON_KNUCKLE'] = {
			label = 'Knuckle Dusters',
			weight = 500,
		},

		['WEAPON_MACHETE'] = {
			label = 'Machete',
			weight = 550,
		},

		['WEAPON_MACHINEPISTOL'] = {
			label = 'Machine Pistol',
			weight = 1250,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_MARKSMANPISTOL'] = {
			label = 'Marksman Pistol',
			weight = 1300,
			ammoname = 'ammo-22'
		},

		['WEAPON_MARKSMANRIFLE'] = {
			label = 'Marksman Rifle',
			weight = 1400,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_MARKSMANRIFLE_MK2'] = {
			label = 'Marksman Rifle',
			weight = 1500,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_MG'] = {
			label = 'Machine Gun',
			weight = 1500,
			ammoname = 'ammo-rifle2'
		},

		['WEAPON_MICROSMG'] = {
			label = 'Micro SMG',
			weight = 1500,
			ammoname = 'smg_ammo'
		},

		['WEAPON_MILITARYRIFLE'] = {
			label = 'Military Rifle',
			weight = 1700,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_MINISMG'] = {
			label = 'Mini SMG',
			weight = 1450,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_MOLOTOV'] = {
			label = 'Molotov',
			weight = 300,
			throwable = true,
		},

		['WEAPON_MUSKET'] = {
			label = 'Musket',
			weight = 1200,
			ammoname = 'ammo-musket'
		},

		['WEAPON_NAVYREVOLVER'] = {
			label = 'Navy Revolver',
			weight = 1100,
			ammoname = 'ammo-44'
		},

		['WEAPON_NIGHTSTICK'] = {
			label = 'Nightstick',
			weight = 650,
		},

		['WEAPON_PETROLCAN'] = {
			label = 'Gas Can',
			weight = 700,
		},

		['WEAPON_PIPEBOMB'] = {
			label = 'Pipe Bomb',
			weight = 800,
			throwable = true,
		},

		['WEAPON_PISTOL'] = {
			label = 'Pistol',
			weight = 1000,
			ammoname = 'ammo-pistol',
		},

		['WEAPON_PISTOL50'] = {
			label = 'Pistol .50',
			weight = 1100,
			ammoname = 'ammo-50'
		},

		['WEAPON_PISTOL_MK2'] = {
			label = 'Pistol MK2',
			weight = 1000,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_POOLCUE'] = {
			label = 'Pool Cue',
			weight = 350,
		},

		['WEAPON_PROXMINE'] = {
			label = 'Proximity Mine',
			weight = 600,
			throwable = true,
		},

		['WEAPON_PUMPSHOTGUN'] = {
			label = 'Pump Shotgun',
			weight = 1400,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_PUMPSHOTGUN_MK2'] = {
			label = 'Pump Shotgun MK2',
			weight = 1500,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_REVOLVER'] = {
			label = 'Revolver',
			weight = 1200,
			ammoname = 'ammo-44'
		},

		['WEAPON_REVOLVER_MK2'] = {
			label = 'Revolver MK2',
			weight = 1300,
			ammoname = 'ammo-44'
		},

		['WEAPON_SAWNOFFSHOTGUN'] = {
			label = 'Sawn Off Shotgun',
			weight = 1400,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_SMG'] = {
			label = 'SMG',
			weight = 1200,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_SMG_MK2'] = {
			label = 'SMG Mk2',
			weight = 1300,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_SMOKEGRENADE'] = {
			label = 'Smoke Grenade',
			weight = 800,
			throwable = true,
		},

		['WEAPON_SNIPERRIFLE'] = {
			label = 'Sniper Rifle',
			weight = 1800,
			ammoname = 'ammo-sniper'
		},

		['WEAPON_SNOWBALL'] = {
			label = 'Snow Ball',
			weight = 100,
			throwable = true,
		},

		['WEAPON_SNSPISTOL'] = {
			label = 'SNS Pistol',
			weight = 950,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_SNSPISTOL_MK2'] = {
			label = 'SNS Pistol MK2',
			weight = 1000,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_SPECIALCARBINE'] = {
			label = 'Special Carbine',
			weight = 1500,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_SPECIALCARBINE_MK2'] = {
			label = 'Special Carbine MK2',
			weight = 1500,
			ammoname = 'ammo-rifle'
		},

		['WEAPON_STICKYBOMB'] = {
			label = 'Sticky Bomb',
			weight = 600,
			throwable = true,
		},

		['WEAPON_STONE_HATCHET'] = {
			label = 'Stone Hatchet',
			weight = 800,
		},

		['WEAPON_STUNGUN'] = {
			label = 'Tazer',
			weight = 700,
		},

		['WEAPON_SWEEPERSHOTGUN'] = {
			label = 'Sweeper Shotgun',
			weight = 1500,
			ammoname = 'ammo-shotgun'
		},

		['WEAPON_SWITCHBLADE'] = {
			label = 'Switch Blade',
			weight = 500,
		},

		['WEAPON_VINTAGEPISTOL'] = {
			label = 'Vintage Pistol',
			weight = 1150,
			ammoname = 'ammo-pistol'
		},

		['WEAPON_WRENCH'] = {
			label = 'Wrench',
			weight = 750,
		},

	},

	Components = {
		['at_flashlight'] = {
			label = 'Latarka do broni',
			weight = 200,
			type = 'flashlight',
			client = {
				component = {`COMPONENT_AT_PI_FLSH`,`COMPONENT_AT_AR_FLSH`},
				usetime = 0
			}
		},

		['silencer'] = {
			label = 'Tłumik',
			weight = 300,
			type = 'barrel',
			client = {
				component = {`COMPONENT_AT_PI_SUPP`, `COMPONENT_AT_PI_SUPP_02`, `COMPONENT_AT_AR_SUPP`, `COMPONENT_AT_AR_SUPP_02`, `COMPONENT_AT_SR_SUPP`, `COMPONENT_AT_SR_SUPP_03`},
				usetime = 0
			}
		},

		['grip'] = {
			label = 'Uchwyt',
			type = 'grip',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_AR_AFGRIP`, `COMPONENT_AT_AR_AFGRIP_02`},
				usetime = 0
			}
		},

		['barrel'] = {
			label = 'Lufa',
			type = 'barrel',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_SR_BARREL_01`,`COMPONENT_AT_MRFL_BARREL_02`,`COMPONENT_AT_MG_BARREL_02`,`COMPONENT_AT_SC_BARREL_02`, `COMPONENT_AT_CR_BARREL_02`, `COMPONENT_AT_BP_BARREL_02`},
				usetime = 0
			}
		},

		['extended_magazine'] = {
			label = 'Powiększony Magazynek',
			type = 'magazine',
			weight = 350,
			client = {
				component = {`COMPONENT_PISTOL_CLIP_02`, `COMPONENT_APPISTOL_CLIP_02`, `COMPONENT_PISTOL_MK2_CLIP_02`, `COMPONENT_SNSPISTOL_MK2_CLIP_02`, `COMPONENT_COMBATPISTOL_CLIP_02`, `COMPONENT_PISTOL50_CLIP_02`, `COMPONENT_HEAVYPISTOL_CLIP_02`, `COMPONENT_SNSPISTOL_CLIP_02`, `COMPONENT_VINTAGEPISTOL_CLIP_02`, `COMPONENT_SMG_CLIP_02`, `COMPONENT_SMG_MK2_CLIP_02`, `COMPONENT_ASSAULTSMG_CLIP_02`, `COMPONENT_MICROSMG_CLIP_02`, `COMPONENT_MINISMG_CLIP_02`, `COMPONENT_COMBATPDW_CLIP_02`, `COMPONENT_MACHINEPISTOL_CLIP_02`, `COMPONENT_HEAVYSHOTGUN_CLIP_02`, `COMPONENT_ASSAULTSHOTGUN_CLIP_02`, `COMPONENT_ASSAULTRIFLE_CLIP_02`, `COMPONENT_CARBINERIFLE_CLIP_02`, `COMPONENT_MILITARYRIFLE_CLIP_02`, `COMPONENT_ADVANCEDRIFLE_CLIP_02`, `COMPONENT_SPECIALCARBINE_CLIP_02`, `COMPONENT_BULLPUPRIFLE_CLIP_02`, `COMPONENT_COMPACTRIFLE_CLIP_02`, `COMPONENT_ASSAULTRIFLE_MK2_CLIP_02`, `COMPONENT_CARBINERIFLE_MK2_CLIP_02`, `COMPONENT_SPECIALCARBINE_MK2_CLIP_02`, `COMPONENT_BULLPUPRIFLE_MK2_CLIP_02`, `COMPONENT_MG_CLIP_02`, `COMPONENT_COMBATMG_CLIP_02`, `COMPONENT_GUSENBERG_CLIP_02`, `COMPONENT_COMBATMG_MK2_CLIP_02`, `COMPONENT_MARKSMANRIFLE_CLIP_02`, `COMPONENT_HEAVYSNIPER_MK2_CLIP_02`, `COMPONENT_MARKSMANRIFLE_MK2_CLIP_02`, `COMPONENT_MACHINEPISTOL_CLIP_03`, `COMPONENT_SMG_CLIP_03`, `COMPONENT_COMBATPDW_CLIP_03`, `COMPONENT_HEAVYSHOTGUN_CLIP_03`, `COMPONENT_COMPACTRIFLE_CLIP_03`, `COMPONENT_CARBINERIFLE_CLIP_03`, `COMPONENT_SPECIALCARBINE_CLIP_03`},
				usetime = 0
			}
		},

		['compensator'] = {
			label = 'Kompensator',
			type = 'barrel',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_PI_COMP_02`, `COMPONENT_AT_PI_COMP_03`, `COMPONENT_AT_PI_COMP`},
				usetime = 0
			}
		},

		['scope'] = {
			label = 'Celownik',
			type = 'sight',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_SIGHTS`, `COMPONENT_AT_SCOPE_MACRO`, `COMPONENT_AT_SCOPE_MACRO_02`, `COMPONENT_AT_SCOPE_MACRO_02_MK2`, `COMPONENT_AT_SCOPE_MACRO`, `COMPONENT_AT_SCOPE_SMALL`, `COMPONENT_AT_SCOPE_SMALL_02`, `COMPONENT_AT_SCOPE_SMALL_MK2`, `COMPONENT_AT_SCOPE_MACRO_MK2`, `COMPONENT_AT_SCOPE_MEDIUM`, `COMPONENT_AT_SCOPE_MEDIUM_MK2`, `COMPONENT_AT_PI_RAIL_02`, `COMPONENT_AT_SCOPE_MAX`, `COMPONENT_AT_SCOPE_LARGE_MK2`, `COMPONENT_AT_SCOPE_NV`},
				usetime = 0
			}
		},

		['scope_thermal'] = {
			label = 'Termowizyjny Celownik',
			type = 'sight',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_SCOPE_THERMAL`},
				usetime = 0
			}
		},

		['muzzle'] = {
			label = 'Kaganiec',
			type = 'barrel',
			weight = 350,
			client = {
				component = {`COMPONENT_AT_MUZZLE_08`, `COMPONENT_AT_MUZZLE_09`, `COMPONENT_AT_MUZZLE_01`, `COMPONENT_AT_MUZZLE_02`, `COMPONENT_AT_MUZZLE_03`, `COMPONENT_AT_MUZZLE_04`, `COMPONENT_AT_MUZZLE_05`, `COMPONENT_AT_MUZZLE_06`, `COMPONENT_AT_MUZZLE_07`},
				usetime = 0
			}
		},

		['skin_gold'] = {
			label = 'Wykończenie Złote',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_MARKSMANRIFLE_VARMOD_LUXE`,`COMPONENT_MARKSMANRIFLE_VARMOD_LUXE`, `COMPONENT_SNIPERRIFLE_VARMOD_LUXE`,`COMPONENT_PUMPSHOTGUN_VARMOD_LOWRIDER`, `COMPONENT_SAWNOFFSHOTGUN_VARMOD_LUXE`,`COMPONENT_ASSAULTRIFLE_VARMOD_LUXE`, `COMPONENT_CARBINERIFLE_VARMOD_LUXE`, `COMPONENT_ADVANCEDRIFLE_VARMOD_LUXE`, `COMPONENT_SPECIALCARBINE_VARMOD_LOWRIDER`, `COMPONENT_BULLPUPRIFLE_VARMOD_LOW`, `COMPONENT_MG_VARMOD_LOWRIDER`,`COMPONENT_PISTOL_VARMOD_LUXE`, `COMPONENT_PISTOL50_VARMOD_LUXE`, `COMPONENT_APPISTOL_VARMOD_LUXE`, `COMPONENT_COMBATPISTOL_VARMOD_LOWRIDER`},
				usetime = 0
			}
		},

		['skin_camo'] = {
			label = 'Wykończenie Camo',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO`,`COMPONENT_COMBATMG_MK2_CAMO`,`COMPONENT_PUMPSHOTGUN_MK2_CAMO`,`COMPONENT_ASSAULTRIFLE_MK2_CAMO`, `COMPONENT_CARBINERIFLE_MK2_CAMO`, `COMPONENT_SPECIALCARBINE_MK2_CAMO`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO`, `COMPONENT_BULLPUPRIFLE_VARMOD_LOW`, `COMPONENT_MG_VARMOD_LOWRIDER`,`COMPONENT_SNSPISTOL_MK2_CAMO`, `COMPONENT_REVOLVER_MK2_CAMO`, `COMPONENT_PISTOL_MK2_CAMO`},
				usetime = 0
			}
		},

		['skin_brushstroke'] = {
			label = 'Wykończenie Brushstroke',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_02`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_02`,`COMPONENT_COMBATMG_MK2_CAMO_02`,`COMPONENT_PUMPSHOTGUN_MK2_CAMO_02`,`COMPONENT_ASSAULTRIFLE_MK2_CAMO_02`, `COMPONENT_CARBINERIFLE_MK2_CAMO_02`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_02`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_02`,`COMPONENT_PISTOL_MK2_CAMO_02`, `COMPONENT_REVOLVER_MK2_CAMO_02`, `COMPONENT_SNSPISTOL_MK2_CAMO_02`},
				usetime = 0
			}
		},

		['skin_woodland'] = {
			label = 'Wykończenie Woodland',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_03`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_03`,`COMPONENT_COMBATMG_MK2_CAMO_03`,`COMPONENT_PUMPSHOTGUN_MK2_CAMO_03`,`COMPONENT_ASSAULTRIFLE_MK2_CAMO_03`, `COMPONENT_CARBINERIFLE_MK2_CAMO_03`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_03`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_03`,`COMPONENT_PISTOL_MK2_CAMO_03`, `COMPONENT_REVOLVER_MK2_CAMO_03`, `COMPONENT_SNSPISTOL_MK2_CAMO_03`},
				usetime = 0
			}
		},

		['skin_skull'] = {
			label = 'Wykończenie Skull',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_04`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_04`, `COMPONENT_COMBATMG_MK2_CAMO_04`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_04`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_04`, `COMPONENT_CARBINERIFLE_MK2_CAMO_04`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_04`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_04`, `COMPONENT_PISTOL_MK2_CAMO_04`, `COMPONENT_REVOLVER_MK2_CAMO_04`, `COMPONENT_SNSPISTOL_MK2_CAMO_04`},
				usetime = 0
			}
		},

		['skin_sessanta'] = {
			label = 'Wykończenie Sessanta',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_05`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_05`, `COMPONENT_COMBATMG_MK2_CAMO_05`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_05`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_05`, `COMPONENT_CARBINERIFLE_MK2_CAMO_05`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_05`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_05`, `COMPONENT_PISTOL_MK2_CAMO_05`, `COMPONENT_REVOLVER_MK2_CAMO_05`, `COMPONENT_SNSPISTOL_MK2_CAMO_05`},
				usetime = 0
			}
		},

		['skin_perseus'] = {
			label = 'Wykończenie Perseus',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_06`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_06`, `COMPONENT_COMBATMG_MK2_CAMO_06`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_06`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_06`, `COMPONENT_CARBINERIFLE_MK2_CAMO_06`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_06`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_06`, `COMPONENT_PISTOL_MK2_CAMO_06`, `COMPONENT_REVOLVER_MK2_CAMO_06`, `COMPONENT_SNSPISTOL_MK2_CAMO_06`},
				usetime = 0
			}
		},

		['skin_leopard'] = {
			label = 'Wykończenie Leopard',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_07`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_07`, `COMPONENT_COMBATMG_MK2_CAMO_07`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_07`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_07`, `COMPONENT_CARBINERIFLE_MK2_CAMO_07`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_07`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_07`, `COMPONENT_PISTOL_MK2_CAMO_07`, `COMPONENT_REVOLVER_MK2_CAMO_07`, `COMPONENT_SNSPISTOL_MK2_CAMO_07`},
				usetime = 0
			}
		},

		['skin_zebra'] = {
			label = 'Wykończenie Zebra',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_08`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_08`,`COMPONENT_COMBATMG_MK2_CAMO_08`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_08`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_08`, `COMPONENT_CARBINERIFLE_MK2_CAMO_08`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_08`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_08`, `COMPONENT_PISTOL_MK2_CAMO_08`, `COMPONENT_REVOLVER_MK2_CAMO_08`, `COMPONENT_SNSPISTOL_MK2_CAMO_08`},
				usetime = 0
			}
		},

		['skin_geometric'] = {
			label = 'Wykończenie Geometric',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_09`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_09`, `COMPONENT_COMBATMG_MK2_CAMO_09`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_09`,`COMPONENT_ASSAULTRIFLE_MK2_CAMO_09`, `COMPONENT_CARBINERIFLE_MK2_CAMO_09`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_09`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_09`, `COMPONENT_PISTOL_MK2_CAMO_09`, `COMPONENT_REVOLVER_MK2_CAMO_09`, `COMPONENT_SNSPISTOL_MK2_CAMO_09`},
				usetime = 0
			}
		},

		['skin_boom'] = {
			label = 'Wykończenie Boom',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_0`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_0`, `COMPONENT_COMBATMG_MK2_CAMO_0`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_0`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_0`, `COMPONENT_CARBINERIFLE_MK2_CAMO_0`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_0`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_0`, `COMPONENT_PISTOL_MK2_CAMO_0`, `COMPONENT_REVOLVER_MK2_CAMO_0`, `COMPONENT_SNSPISTOL_MK2_CAMO_0`},
				usetime = 0
			}
		},

		['skin_patriotic'] = {
			label = 'Wykończenie Patriotic',
			type = 'skin',
			weight = 10,
			client = {
				component = {`COMPONENT_HEAVYSNIPER_MK2_CAMO_IND_01`, `COMPONENT_MARKSMANRIFLE_MK2_CAMO_IND_01`, `COMPONENT_COMBATMG_MK2_CAMO_IND_01`, `COMPONENT_PUMPSHOTGUN_MK2_CAMO_IND_01`, `COMPONENT_ASSAULTRIFLE_MK2_CAMO_IND_01`, `COMPONENT_CARBINERIFLE_MK2_CAMO_IND_01`, `COMPONENT_SPECIALCARBINE_MK2_CAMO_IND_01`, `COMPONENT_BULLPUPRIFLE_MK2_CAMO_IND_01`, `COMPONENT_SNSPISTOL_MK2_CAMO_IND_01_SLIDE`, `COMPONENT_REVOLVER_MK2_CAMO_IND_01`, `COMPONENT_PISTOL_MK2_CAMO_IND_01`},
				usetime = 0
			}
		},
	},

	Ammo = {
		['ammo-22'] = {
			label = '.22 Long Rifle',
			weight = 95,
		},

		['ammo-38'] = {
			label = '.38 Long Colt',
			weight = 60,
		},

		['ammo-44'] = {
			label = '.44 Magnum',
			weight = 70,
		},

		['smg_ammo'] = {
			label = 'SMG Ammo',
			weight = 90,
		},

		['ammo-50'] = {
			label = '.50 AE',
			weight = 50,
		},

		['ammo-pistol'] = {
			label = 'Pistol Ammo',
			weight = 50,
		},

		['ammo-flare'] = {
			label = 'Flare',
			weight = 50,
		},

		['ammo-heavysniper'] = {
			label = 'Heavy Ammo',
			weight = 100,
		},

		['ammo-musket'] = {
			label = 'Musket Ammo',
			weight = 50,
		},

		['ammo-rifle'] = {
			label = 'Rifle Ammo',
			weight = 50,
		},

		['ammo-rifle2'] = {
			label = 'Rifle Ammo 2',
			weight = 50,
		},

		['ammo-shotgun'] = {
			label = 'Shotgun Ammo',
			weight = 50,
		},

		['ammo-sniper'] = {
			label = 'Sniper Ammo',
			weight = 50,
		}
	}
}
