return {
	['testburger'] = {
		label = 'Test Burger',
		weight = 220,
		degrade = 60,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
			export = 'ox_inventory_examples.testburger'
		},
		server = {
			export = 'ox_inventory_examples.testburger',
			test = 'what an amazingly delicious burger, amirite?'
		},
		buttons = {
			{
				label = 'Lick it',
				action = function(slot)
					print('You licked the burger')
				end
			},
			{
				label = 'Squeeze it',
				action = function(slot)
					print('You squeezed the burger :(')
				end
			}
		}
	},

	['bandage'] = {
		label = 'Bandaż',
		client = {
			anim = { dict = 'missheistdockssetup1clipboard@idle_a', clip = 'idle_a', flag = 49 },
			prop = { model = `prop_rolled_sock_02`, pos = vec3(-0.14, -0.14, -0.08), rot = vec3(-50.0, -50.0, 0.0) },
			disable = { move = true, car = true, combat = true },
			usetime = 2500,
		}
	},

	['black_money'] = {
		label = 'Oznakowana Gotówka',
	},

	['sim'] = {
		label = 'Karta Sim',
		weight = 10,
	},

	['lhseed'] = {
		label = 'Nasiona Lemon Haze',
		weight = 10,
	},

	['weed_lemon'] = {
		label = 'Lemon Haze',
		weight = 20,
	},

	['scratchcard2'] = {
		label = 'Zdrapka',
		weight = 5,
	},

	['scratchcardgold2'] = {
		label = 'Zdrapka Gold',
		weight = 5,
	},

	['scratchcardpremium2'] = {
		label = 'Zdrapka Premium',
		weight = 5,
	},

	['id_card_f'] = {
		label = 'Karta Dostępu',
	},

	['secure_card'] = {
		label = 'Karta Bezpieczeństwa',
	},

	['milk'] = {
		label = 'Mleko',
		weight = 400,
		client = {
			status = { thirst = 150000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_cs_milk_01`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['bun'] = {
		label = 'Bułka',
		weight = 100,
	},

	['morela'] = {
		label = 'Morela',
		weight = 300,
	},

	['cucumbers'] = {
		label = 'Ogórek',
		weight = 250,
	},

	['chicken'] = {
		label = 'Kurczak',
		weight = 800,
	},

	['meat'] = {
		label = 'Mięso',
		weight = 700,
	},

	['tomato'] = {
		label = 'Pomidor',
		weight = 140,
	},
	
	['salad'] = {
		label = 'Sałata',
		weight = 100,
	},
	
	['tortilla'] = {
		label = 'Tortilla',
		weight = 110,
	},

	['wanilia'] = {
		label = 'Wanilia',
		weight = 50,
	},

	['cocoa'] = {
		label = 'Nasiona Kakao',
		weight = 40,
	},

	['coffe'] = {
		label = 'Nasiona Kawy',
		weight = 45,
	},

	['flour'] = {
		label = 'Mąka',
		weight = 400,
	},

	['kulki'] = {
		label = 'Kulki Boba',
		weight = 300,
	},

	['malina'] = {
		label = 'Malina',
		weight = 200,
	},

	['rice'] = {
		label = 'Ryż',
		weight = 200,
	},

	['salmon'] = {
		label = 'Łosoś',
		weight = 200,
	},

	['strawberry'] = {
		label = 'Truskawka',
		weight = 200,
	},

	['lighter'] = {
		label = 'Zapalniczka',
		weight = 400,
	},

	['sugar'] = {
		label = 'Cukier',
		weight = 300,
	},

	['cigarette'] = {
		label = 'Papieros',
		weight = 30,
	},

	['ocb_paper'] = {
		label = 'Bletka',
		weight = 20,
	},

	['cigarettespack'] = {
		label = 'Paczka Papierosów',
		weight = 30,
	},

	['lh_joint'] = {
		label = 'Lemonhaze Joint',
		crafting = {
			['ocb_paper'] = 2,
			['weed'] = 1,
	    }
	},	

	['binoculars'] = {
		label = 'Lornetka',
		weight = 700,
	},

	['pierscionek'] = {
		label = 'Pierścionek',
		weight = 800,
	},

	['beer'] = {
		label = 'Piwo',
		weight = 500,
	},

	['vodka'] = {
		label = 'Wódka',
		weight = 500,
	},

	['rose'] = {
		label = 'Róża',
		weight = 50,
	},

	['waniliashake'] = {
		label = 'Shake Waniliowy',
		weight = 300,
		client = {
			status = { thirst = 500000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_cs_bs_cup`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['morelshake'] = {
		label = 'Shake Morelowy',
		weight = 300,
		client = {
			status = { thirst = 500000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_cs_bs_cup`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['bsfries'] = {
		label = 'Frytki',
		weight = 200,
		client = {
			status = { hunger = 400000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['nuts'] = {
		label = 'Orzeszki',
		weight = 100,
		client = {
			status = { hunger = 100000 },
			anim = 'eating',
			prop = 'prop_bar_nuts',
			usetime = 2700,
		},
	},

	['chickenburger'] = {
		label = 'Chick Burger',
		weight = 500,
		client = {
			status = { hunger = 400000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['cheeseburger'] = {
		label = 'Cheese Burger',
		weight = 500,
		client = {
			status = { hunger = 400000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['bswrap'] = {
		label = 'BS Wrap',
		weight = 500,
		client = {
			status = { hunger = 400000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['bsnuggets'] = {
		label = 'BS Nuggets',
		weight = 500,
		client = {
			status = { hunger = 400000 },
			anim = 'eating',
			prop = 'prop_food_cb_nugets',
			usetime = 2500,
		},
	},

	['burger'] = {
		label = 'Burger',
		weight = 300,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['hotdog'] = {
		label = 'Hotdog',
		weight = 250,
		client = {
			status = { hunger = 150000 },
			anim = 'eating',
			prop = 'prop_cs_hotdog_01',
			usetime = 2500,
		},
	},

	['bar'] = {
		label = 'Czekolada',
		weight = 200,
		client = {
			status = { hunger = 100000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2000,
		},
	},

	['candy'] = {
		label = 'Żelki',
		weight = 230,
		client = {
			status = { hunger = 90000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2300,
		},
	},

	['sandwich'] = {
		label = 'Kanapka',
		weight = 140,
		client = {
			status = { hunger = 100000 },
			anim = 'eating',
			prop = 'burger',
			usetime = 2500,
		},
	},

	['chipsribs'] = {
		label = 'Chipsy Żeberkowe',
		weight = 200,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'v_ret_ml_chips1',
			usetime = 3500,
		},
	},

	['chipscheese'] = {
		label = 'Chipsy Serowe',
		weight = 200,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'v_ret_ml_chips4',
			usetime = 3500,
		},
	},

	['chipssalt'] = {
		label = 'Chipsy Solone',
		weight = 200,
		client = {
			status = { hunger = 200000 },
			anim = 'eating',
			prop = 'v_ret_ml_chips3',
			usetime = 3500,
		},
	},

	['taco'] = {
		label = 'Taco',
		weight = 300,
		client = {
			status = { hunger = 220000 },
			anim = 'eating',
			prop = 'prop_taco_01',
			usetime = 3000,
		},
	},

	['cola'] = {
		label = 'eCola',
		weight = 250,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ecola_can`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['coffee'] = {
		label = 'Kawa',
		weight = 250,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `p_ing_coffeecup_01`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['sprunk'] = {
		label = 'Sprunk',
		weight = 250,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ld_can_01`, pos = vec3(0.01, 0.01, 0.06), rot = vec3(5.0, 5.0, -180.5) },
			usetime = 2500,
		}
	},

	['parachute'] = {
		label = 'Spadochron',
		weight = 900,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
			usetime = 1500
		}
	},

	['garbage'] = {
		label = 'Śmieci',
	},

	['paperbag'] = {
		label = 'Papierowa Torba',
		weight = 100,
		stack = false,
		close = false,
		consume = 0
	},

	['torba'] = {
		label = 'Torba',
		weight = 500,
		stack = false,
		close = false,
		consume = 0
	},

	['panties'] = {
		label = 'Knickers',
		consume = 0,
		client = {
			status = { thirst = -100000, stress = -25000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_cs_panties_02`, pos = vec3(0.03, 0.0, 0.02), rot = vec3(0.0, -13.5, -1.5) },
			usetime = 2500,
		}
	},

	['lockpick'] = {
		label = 'Wytrych',
		consume = 0,
		client = {
			anim = { dict = 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@', clip = 'machinic_loop_mechandplayer' },
			disable = { move = true, car = true, combat = true },
			usetime = 5000,
			cancel = true
		}
	},

	['phone'] = {
		label = 'Telefon',
		weight = 100,
	},

	['radio'] = {
		label = 'Radio',
		weight = 140,
	},

	['money'] = {
		label = 'Gotówka',
	},

	['laptop'] = {
		label = 'Laptop',
		weight = 1000,
	},

	['mustard'] = {
		label = 'Musztarda',
		weight = 300,
		client = {
			status = { hunger = 25000, thirst = 25000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_food_mustard`, pos = vec3(0.01, 0.0, -0.07), rot = vec3(1.0, 1.0, -1.5) },
			usetime = 2500,
		}
	},

	['water'] = {
		label = 'Woda',
		weight = 300,
		client = {
			status = { thirst = 200000 },
			anim = { dict = 'mp_player_intdrink', clip = 'loop_bottle' },
			prop = { model = `prop_ld_flow_bottle`, pos = vec3(0.03, 0.03, 0.02), rot = vec3(0.0, 0.0, -1.5) },
			usetime = 2500,
			cancel = true,
		}
	},

	['radio'] = {
		label = 'Radio',
		stack = false,
		consume = 0,
		allowArmed = true
	},

	['armour'] = {
		label = 'Kamizelka Kuloodporna',
		weight = 800,
		stack = false,
		client = {
			anim = { dict = 'clothingshirt', clip = 'try_shirt_positive_d' },
            usetime = 3500
		}
	},

	['carcass_boar'] = {
		label = 'Dzik',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},
	['carcass_hawk'] = {
		label = 'Jastrząb',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},
	
	['carcass_cormorant'] = {
		label = 'Kormoran',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},

	['carcass_coyote'] = {
		label = 'Kojot',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},

	['carcass_deer'] = {
		label = 'Jeleń',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},

	['carcass_mtlion'] = {
		label = 'Lew',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},

	['carcass_rabbit'] = {
		label = 'Królik',
		weight = 2000,
		stack = false,
		degrade = 5*60,
		client = {
            add = function()
                TriggerEvent('nfire_hunting:CarryCarcass')
            end,
            remove = function()
		TriggerEvent('nfire_hunting:CarryCarcass')
            end
        }
	},

	['fish'] = {
		label = 'fish',
		stack = true,
		close = true,
		description = nil
	},

	['fixkit'] = {
		label = 'Zestaw Naprawczy',
		weight = 650,
		stack = true,
		close = true,
		description = nil
	},
	
	['rope'] = {
		label = 'Lina',
		weight = 200,
	},

	['handcuffs'] = {
		label = 'Kajdanki',
		weight = 200,
	},

	['alive_chicken'] = {
		label = 'living chicken',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['blowpipe'] = {
		label = 'blowtorch',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['bread'] = {
		label = 'bread',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['cannabis'] = {
		label = 'cannabis',
		weight = 3,
		stack = true,
		close = true,
		description = nil
	},

	['carokit'] = {
		label = 'body kit',
		weight = 3,
		stack = true,
		close = true,
		description = nil
	},

	['carotool'] = {
		label = 'tools',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['clothe'] = {
		label = 'cloth',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['copper'] = {
		label = 'copper',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['cutted_wood'] = {
		label = 'cut wood',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['diamond'] = {
		label = 'diamond',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['essence'] = {
		label = 'gas',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['fabric'] = {
		label = 'fabric',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['fixtool'] = {
		label = 'repair tools',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['gazbottle'] = {
		label = 'gas bottle',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['gold'] = {
		label = 'gold',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['iron'] = {
		label = 'iron',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['marijuana'] = {
		label = 'marijuana',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['medikit'] = {
		label = 'medikit',
		weight = 2,
		stack = true,
		close = true,
		description = nil
	},

	['packaged_chicken'] = {
		label = 'chicken fillet',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['packaged_plank'] = {
		label = 'packaged wood',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['petrol'] = {
		label = 'oil',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['petrol_raffin'] = {
		label = 'processed oil',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['slaughtered_chicken'] = {
		label = 'slaughtered chicken',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['stone'] = {
		label = 'stone',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['washed_stone'] = {
		label = 'washed stone',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['wood'] = {
		label = 'wood',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},

	['wool'] = {
		label = 'wool',
		weight = 1,
		stack = true,
		close = true,
		description = nil
	},
}